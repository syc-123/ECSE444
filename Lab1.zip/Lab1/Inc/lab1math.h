/*
 * lab1math.h
 *
 *  Created on: 2020.9.13
 *      Author: yicheng
 */

 #include "main.h"

#ifndef INC_LAB1MATH_H_
#define INC_LAB1MATH_H_

void cMax(float *array, uint32_t size, float *max, uint32_t *maxIndex);

extern void asmMax(float *array, uint32_t size, float *max, uint32_t *maxIndex);

void C_multiplication(float *arrayA, float *arrayB, float *result, uint32_t *size);

extern void asm_multiplication(float *arrayA, float *arrayB, float *result, uint32_t size);

void C_Sdeviation(float *arrayA, float *result, uint32_t size);

extern void asm_Sdeviation(float *arrayA, uint32_t size, float *result);

#endif /* INC_LAB1MATH_H_ */
