/*
 * multiplication.c
 *
 *  Created on: 2020.9.13
 *      Author: yicheng
 */

#include "main.h"

void C_multiplication(float *arrayA, float *arrayB, float *result, uint32_t *size){
	for (uint32_t i = 0; i < size; i++){
		result[i] = arrayA[i]*arrayB[i];
	}
}
