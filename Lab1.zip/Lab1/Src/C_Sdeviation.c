/*
 * C_Sdeviation.c
 *
 *  Created on: 2020.9.14.
 *      Author: yicheng
 */

#include "main.h"

void C_Sdeviation(float *arrayA, float *result, uint32_t size){
	float mean = 0;
	float dev = 0;
	for (uint32_t i = 0; i < size; i++){
		mean += arrayA[i];
	}
	mean = mean / size;
	for (uint32_t i = 0; i < size; i++){
		dev += powf(arrayA[i] - mean, 2);
	}
	*result = sqrtf(dev/(size-1));
}
